
# Security Model

Threat mitigations:

Timing attacks:
- Zig verifier uses constant‑time operations.

Memory corruption:
- Vale prover ensures memory safety with ownership model.

Proof forgery:
- Challenge transcript validation.

Governance manipulation:
- Bosque rule validation on proposals.
