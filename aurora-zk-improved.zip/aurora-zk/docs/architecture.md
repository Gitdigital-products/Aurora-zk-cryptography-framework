
# Aurora-ZK Architecture

Stages:

1. Mojo circuits define constraints
2. Witness builder produces witness values
3. Vale prover generates ZK proof
4. Zig verifier validates proof
5. Gleam compliance engine enforces rules
6. Bosque governance evaluates proposals
7. Ballerina API exposes services
8. V SDK allows developer integration
