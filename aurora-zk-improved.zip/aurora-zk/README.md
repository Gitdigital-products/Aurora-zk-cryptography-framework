
# Aurora-ZK Cryptography Framework (Improved)

Aurora‑ZK is a multi‑language zero‑knowledge cryptography framework designed for high performance,
strong security guarantees, and clear governance layers.

Pipeline:
Circuit → Witness → Proof → Verification → Compliance → Governance → API → SDK

Languages used:
- Mojo (circuits + witness)
- Vale (memory‑safe prover)
- Zig (constant‑time verifier)
- Gleam (compliance rules)
- Bosque (governance logic)
- Ballerina (API layer)
- V (developer SDK)

This improved version focuses on:
- Faster circuits
- Memory‑safe proof generation
- Constant‑time verification
- Deterministic CI builds
- Governance‑linked proofs
