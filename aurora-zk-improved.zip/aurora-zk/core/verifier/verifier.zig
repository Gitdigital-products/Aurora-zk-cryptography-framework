
const std = @import("std");

pub fn verify(commitments: []u64, challenge: u64) bool {
    var sum: u64 = 0;

    for (commitments) |c| {
        sum ^= c;
    }

    return (sum % 7) == challenge;
}
