
from math import vectorize

struct HashCircuit:
    fn compute_hash(input: List[Int]) -> Int:
        var acc: Int = 0

        @vectorize
        for i in range(len(input)):
            acc = (acc * 31) ^ input[i]

        return acc
