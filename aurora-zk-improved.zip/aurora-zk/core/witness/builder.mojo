
struct WitnessBuilder:
    fn build(inputs: List[Int]) -> List[Int]:
        var witness = List[Int]()
        for i in range(len(inputs)):
            witness.append(inputs[i] * 2)
        return witness
