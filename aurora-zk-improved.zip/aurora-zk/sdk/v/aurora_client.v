
module aurora

pub struct Proof {
    commitments []int
    challenge int
}

pub fn verify(p Proof) bool {
    return p.challenge > 0
}
