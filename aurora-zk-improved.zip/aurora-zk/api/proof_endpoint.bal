
import ballerina/http;

service /proof on new http:Listener(8080) {

    resource function post verify(json payload) returns json {

        boolean valid = payload.challenge > 0;

        return { valid: valid };
    }
}
