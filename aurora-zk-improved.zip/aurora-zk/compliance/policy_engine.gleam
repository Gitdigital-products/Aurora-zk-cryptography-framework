
pub type Proof {
  commitments: List(Int),
  challenge: Int
}

pub fn validate(proof: Proof) -> Bool {
  case proof.challenge > 0 {
    True -> True
    False -> False
  }
}
